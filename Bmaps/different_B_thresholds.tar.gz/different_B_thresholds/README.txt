The different thresholds used for these maps correspond to those shown in 
Figure S7 and S9 of Section 1.5 of the supplement of Murphy et al. 2021.
The thresholds on B were applied to the lookup tables of B.